import React from 'react'
import Table from './Table';

const Dashboard = () => {

    

  return (
    <div>
          <h1>Parking Table</h1>
          <Table />
    </div>
  )
}

export default Dashboard
