import React from 'react'
import ParkingDisplay from './Components/ParkingDisplay'

const App = () => {
  return (
    <div>
      <ParkingDisplay/>
    </div>
  )
}

export default App
