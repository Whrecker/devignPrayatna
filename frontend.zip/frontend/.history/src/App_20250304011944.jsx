import React from 'react'

const App = () => {
  return (
    <div>
      <P
    </div>
  )
}

export default App
